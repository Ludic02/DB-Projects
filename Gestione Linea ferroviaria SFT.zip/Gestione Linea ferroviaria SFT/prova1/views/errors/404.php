<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6 text-center">
            <h1 class="display-1">404</h1>
            <h2>Pagina non trovata</h2>
            <p class="lead">La pagina che stai cercando non esiste o è stata spostata.</p>
            <a href="index.php" class="btn btn-primary">Torna alla Home</a>
        </div>
    </div>
</div>