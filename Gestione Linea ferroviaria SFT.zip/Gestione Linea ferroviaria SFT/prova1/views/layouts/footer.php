</div>
    <footer class="footer mt-5 py-3 bg-light">
        <div class="container">
            <span class="text-muted">© 2024 Società Ferrovie Turistiche. Tutti i diritti riservati.</span>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
</body>
</html>